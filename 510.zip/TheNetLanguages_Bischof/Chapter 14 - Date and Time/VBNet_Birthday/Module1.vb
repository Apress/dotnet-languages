'Working with your birthday in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Dim birthday, nextBirthday As DateTime
        Dim Today As DateTime = DateTime.Now
        Dim ts As TimeSpan
        Dim value As Integer
        'Get the user's birthday
        Console.WriteLine("What day were you born?")
        birthday = DateTime.Parse(Console.ReadLine())
        'Is it a leap year?
        If (DateTime.IsLeapYear(birthday.Year)) Then
            Console.WriteLine("You were born on a leap year!")
        Else
            Console.WriteLine("This is not a leap year")
        End If
        'Calculate the next birthday
        nextBirthday = New DateTime(Today.Year, birthday.Month, _
            birthday.Day)
        If (Today.Month > birthday.Month) Then
            nextBirthday = nextBirthday.AddYears(1)
        End If
        Console.WriteLine("Your next birthday is {0}", _
            nextBirthday.ToShortDateString())
        'Use the Date property for subtraction.
        ts = nextBirthday.Subtract(Today.Date)
        Console.WriteLine("It is {0} days from now", ts.Days)
        'What happens if we use the TimeSpan for the calculation?
        ts = nextBirthday.Subtract(Today)
        Console.WriteLine("Using TimeSpan - It is {0} days from now", _
            ts.Days)
        Console.ReadLine()
    End Sub
End Module
