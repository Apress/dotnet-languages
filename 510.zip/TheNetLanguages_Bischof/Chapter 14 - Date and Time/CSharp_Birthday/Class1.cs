//Working with your birthday in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Birthday
{
    class Class1
    {
        static void Main(string[] args)
        {
            DateTime birthday, nextBirthday;
            DateTime today = DateTime.Now;
            TimeSpan ts;
            int value;    
            //Get the user's birthday
            Console.WriteLine("What day were you born?");
            birthday = DateTime.Parse(Console.ReadLine());            
            //Is it a leap year?
            if (DateTime.IsLeapYear(birthday.Year))
            {
                Console.WriteLine("You were born on a leap year!");
            }
            else
            {
                Console.WriteLine("This is not a leap year");
            }
            //Calculate the next birthday
            nextBirthday = new DateTime(today.Year, birthday.Month, 
                birthday.Day);
            if (today.Month > birthday.Month)
            {
                nextBirthday = nextBirthday.AddYears(1);
            } 
            Console.WriteLine("Your next birthday is {0}", 
                nextBirthday.ToShortDateString());
            //Use the Date property for subtraction.
            ts = nextBirthday.Subtract(today.Date);
            Console.WriteLine("It is {0} days from now", ts.Days);
            //What happens if we use the TimeSpan for the calculation?
            ts = nextBirthday.Subtract(today);
            Console.WriteLine("Using TimeSpan - It is {0} days from now", 
                ts.Days);            
            Console.ReadLine();
        }
    }
}
