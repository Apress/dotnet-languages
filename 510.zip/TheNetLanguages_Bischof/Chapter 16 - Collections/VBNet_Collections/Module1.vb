'Managing a collection in VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Dim myCollection As Hashtable = New Hashtable(101)
        Dim menuItem As Integer
        Dim key, data As String
        Dim myEntry As DictionaryEntry
        Do
            Console.WriteLine()
            Console.WriteLine("Collection Menu")
            Console.WriteLine("Total Elements: {0}", myCollection.Count)
            Console.WriteLine("1. Add string")
            Console.WriteLine("2. Modify string")
            Console.WriteLine("3. Remove string")
            Console.WriteLine("4. List collection")
            Console.WriteLine("0. Exit")
            Console.Write("Selection: ")
            menuItem = Integer.Parse("0" & Console.ReadLine())
            Select Case menuItem
            Case 1 'Add an element
                Console.Write("Key: ")
                key = Console.ReadLine()
                Console.Write("String: ")
                data = Console.ReadLine()
                'Make sure it doesn't exist yet
                If (myCollection.ContainsKey(key)) Then
                    Console.WriteLine("Key already exists")
                Else
                    myCollection.Add(key, data)
                End If
            Case 2 'Modify data
                Console.Write("Key: ")
                key = Console.ReadLine()
                Console.Write("String: ")
                data = Console.ReadLine()
                'Check if it already exists
                If (myCollection.ContainsKey(key)) Then
                    'It does exist, so modify it
                    myCollection(key) = data
                Else
                    'It doesn't exist, lets add it
                    myCollection.Add(key, data)
                End If
            Case 3 'Remove an element
                Console.Write("Key: ")
                key = Console.ReadLine()
                'Make sure it exists before we delete it
                If (myCollection.ContainsKey(key)) Then
                    myCollection.Remove(key)
                Else
                    Console.WriteLine("Key doesn't exist")
                End If
            Case 4 'List the elements
                For Each myEntry In myCollection
                    Console.WriteLine("{0}: {1}", myEntry.Key, _
                        myEntry.Value)
                Next
                End Select
        Loop While menuItem <> 0
    End Sub
End Module
