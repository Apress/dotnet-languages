//Managing a collection in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.Collections;

namespace C_Collections
{
    class Class1
    {
        static void Main(string[] args)
        {
            Hashtable myCollection = new Hashtable(101);
            int menuItem = 0;
            string key="", data="";
            do
            {
                Console.WriteLine("\nCollection Menu");
                Console.WriteLine("Total Elements: {0}", myCollection.Count);
                Console.WriteLine("1. Add string");
                Console.WriteLine("2. Modify string");
                Console.WriteLine("3. Remove string");
                Console.WriteLine("4. List collection");
                Console.WriteLine("0. Exit");
                Console.Write("Selection: ");
                menuItem = int.Parse("0" + Console.ReadLine());
                switch (menuItem)
                {
                    case 1:     //Add an element
                        Console.Write("Key: ");
                        key = Console.ReadLine();
                        Console.Write("String: ");
                        data = Console.ReadLine();
                        //Make sure it doesn't exist yet
                        if (myCollection.ContainsKey(key))
                        {
                            Console.WriteLine("Key already exists");
                        }
                        else
                        {
                            myCollection.Add(key, data);
                        }
                        break;
                    case 2:     //Modify data
                        Console.Write("Key: ");
                        key = Console.ReadLine();
                        Console.Write("String: ");
                        data = Console.ReadLine();
                        //Check if it already exists
                        if (myCollection.ContainsKey(key))
                        {   //It does exist, so modify it
                            myCollection[key] = data;
                        }
                        else
                        {   //It doesn't exist, lets add it
                            myCollection.Add(key, data);
                        }
                        break;
                    case 3:     //Remove an element
                        Console.Write("Key: ");
                        key = Console.ReadLine();
                        //Make sure it exists before we delete it
                        if (myCollection.ContainsKey(key))
                        {
                            myCollection.Remove(key);
                        }
                        else
                        {
                            Console.WriteLine("Key doesn't exist");
                        }
                        break;
                    case 4:     //List the elements
                        foreach (DictionaryEntry myEntry in myCollection) 
                        {
                            Console.WriteLine("{0}: {1}", myEntry.Key, 
                                myEntry.Value);
                        } 
                        break;
                }        

            }while (menuItem!=0);
        }
    }
}
