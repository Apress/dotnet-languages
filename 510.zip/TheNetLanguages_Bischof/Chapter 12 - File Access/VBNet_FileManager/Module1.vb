'Managing files and directories in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.IO
Imports System.Data
Module Module1

    Sub Main()
        Dim menuItem As Integer
        Dim currentDirectory, input1, input2 As String
        Dim fileNames() As String, currentFile As String
        'FileAttributes fileAttr
        Console.WriteLine("File Manager")
        Do
            currentDirectory = Directory.GetCurrentDirectory()
            Console.WriteLine()
            Console.WriteLine("Current Directory: {0}", currentDirectory)
            Console.WriteLine("1. Create Directory")
            Console.WriteLine("2. Change Directory")
            Console.WriteLine("3. List File in Directory")
            Console.WriteLine("4. Get File Times")
            Console.WriteLine("5. Copy a File")
            Console.WriteLine("6. Rename a File")
            Console.WriteLine("0. Exit")
            Console.Write("Which function to perform? ")
            menuItem = Integer.Parse("0" + Console.ReadLine())
            Select Case menuItem
                Case 1 'Create directory
                    Console.Write("New Directory: ")
                    input1 = Console.ReadLine()
                    Directory.CreateDirectory(input1)
                Case 2 'Change directory
                    Console.Write("Change to: ")
                    input1 = Console.ReadLine()
                    Directory.SetCurrentDirectory(input1)
                Case 3 'List files in directory
                    Console.Write("File Search Pattern: ")
                    input1 = Console.ReadLine()
                    If (input1 = "") Then
                        input1 = "*.*"
                    End If
                    fileNames = Directory.GetFiles(currentDirectory, input1)
                    For Each currentFile In fileNames
                        Console.WriteLine(currentFile.ToString())
                    Next
                Case 4 'Get file times
                    Console.Write("Filename: ")
                    input1 = Console.ReadLine()
                    'fileAttr=File.GetAttributes(input1)
                    Console.WriteLine("Created: {0}", _
                        File.GetCreationTime(input1))
                    Console.WriteLine("Modified: {0}", _
                        File.GetLastWriteTime(input1))
                    Console.WriteLine("Accessed: {0}", _
                        File.GetLastAccessTime(input1).ToShortDateString())
                Case 5 'Copy a file
                    Console.Write("Filename: ")
                    input1 = Console.ReadLine()
                    Console.Write("Copy to: ")
                    input2 = Console.ReadLine()
                    File.Copy(input1, input2)
                Case 6 'Rename a file
                    Console.Write("Filename: ")
                    input1 = Console.ReadLine()
                    Console.Write("New Filename: ")
                    input2 = Console.ReadLine()
                    File.Move(input1, input2)
            End Select
        Loop While (menuItem <> 0)
    End Sub
End Module
