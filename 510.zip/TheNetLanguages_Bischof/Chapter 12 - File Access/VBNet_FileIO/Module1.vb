'Reading and writing text files in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.IO

Module Module1

    Sub Main()
            Dim menuItem As Integer
            Dim input, fileLine As String
            Dim outFile As StreamWriter
            Dim inFile As StreamReader
            Console.WriteLine("Text File I/O")
            Do
                Console.WriteLine()
                Console.WriteLine("1: Read from file")
                Console.WriteLine("2: Write to a file")
                Console.Write("Which function to perform? ")
                menuItem = Integer.Parse("0" + Console.ReadLine())
                Select Case menuItem
                    Case 1 'Read from a file
                        Console.Write("Filename: ")
                        input = Console.ReadLine()
                        'Open the input file
                        inFile = New StreamReader(input)
                        fileLine = inFile.ReadLine()
                        'Read from the file until we reach the end
                        While (fileLine <> Nothing)
                            Console.WriteLine(fileLine)
                            'Get the next line from the file
                            fileLine = inFile.ReadLine()
                        End While
                        inFile.Close()
                    Case 2 'Write to a file
                        Console.Write("Filename: ")
                        input = Console.ReadLine()
                        'Open the output file
                        outFile = New StreamWriter(input)
                        fileLine = Console.ReadLine()
                        Do While fileLine <> ""
                            'Write the user's input to the file
                            outFile.WriteLine(fileLine)
                            fileLine = Console.ReadLine()
                        Loop
                        outFile.Close()
                End Select
            Loop Until menuItem = 0
    End Sub
End Module
