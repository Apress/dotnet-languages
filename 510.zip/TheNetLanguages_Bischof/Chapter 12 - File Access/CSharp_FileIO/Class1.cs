//Reading and writing text files in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.IO;
namespace C_FileIO
{
    class Class1
    {
        static void Main(string[] args)
        {
            int menuItem=0;
            string input="", fileLine="";
            StreamWriter outFile;
            StreamReader inFile;
            Console.WriteLine("Text File I/O");
            do
            {
                Console.WriteLine("\n1: Read from file");
                Console.WriteLine("2: Write to a file");
                Console.Write("Which function to perform? ");
                menuItem = int.Parse("0"+Console.ReadLine());
                switch (menuItem)
                {
                    case 1:     //Read from a file
                        Console.Write("Filename: ");
                        //Open the input file
                        input=Console.ReadLine();
                        inFile=new StreamReader(input);
                        //Read from the file until we reach the end
                        while ((fileLine=inFile.ReadLine())!=null)
                        {
                            Console.WriteLine(fileLine);
                        }
                        inFile.Close();
                        break;
                    case 2:     //Write to a file
                        Console.Write("Filename: ");
                        input=Console.ReadLine();
                        //Open the output file
                        outFile=new StreamWriter(input);                      
                        fileLine=Console.ReadLine();
                        while (fileLine != "")
                        { 
                            //Write the user's input to the file
                            outFile.WriteLine(fileLine);
                            fileLine=Console.ReadLine();                                              } 
                        outFile.Close();
                        break;
                }
            } while (menuItem!=0);
        }
    }
}
