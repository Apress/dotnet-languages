//Managing files and directories in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.IO;
using System.Data;
namespace C_FileManagement
{
    class Class1
    {
        static void Main(string[] args)
        {
            int menuItem=0;
            string currentDirectory="", input1="", input2="";
            string[] files;
            //FileAttributes fileAttr;
            Console.WriteLine("File Manager");
            do
            {
                currentDirectory = Directory.GetCurrentDirectory();
                Console.WriteLine("\nCurrent Directory: {0}",currentDirectory);
                Console.WriteLine("1. Create Directory");
                Console.WriteLine("2. Change Directory");
                Console.WriteLine("3. List File in Directory");
                Console.WriteLine("4. Get File Times");
                Console.WriteLine("5. Copy a File");
                Console.WriteLine("6. Rename a File");
                Console.WriteLine("0. Exit");
                Console.Write("Which function to perform? ");
                menuItem=int.Parse("0" + Console.ReadLine());
                switch (menuItem)
                {
                    case 1:     //Create directory
                        Console.Write("New Directory: ");
                        input1=Console.ReadLine();
                        Directory.CreateDirectory(input1);
                        break;
                    case 2:     //Change directory
                        Console.Write("Change to: ");
                        input1=Console.ReadLine();
                        Directory.SetCurrentDirectory(input1);
                        break;
                    case 3:     //List files in directory
                        Console.Write("File Search Pattern: ");
                        input1=Console.ReadLine();
                        if (input1=="")
                        {
                            input1="*.*";
                        }
                        files = Directory.GetFiles(currentDirectory,input1);
                        foreach(string file in files)
                        {
                            Console.WriteLine(file.ToString());
                        }
                        break;
                    case 4:     //Get file times
                        Console.Write("Filename: ");
                        input1=Console.ReadLine();
                        //fileAttr=File.GetAttributes(input1);
                        Console.WriteLine("Created: {0}", 
                            File.GetCreationTime(input1));
                        Console.WriteLine("Modified: {0}",
                            File.GetLastWriteTime(input1));
                        Console.WriteLine("Accessed: {0}",
                            File.GetLastAccessTime(input1).ToShortDateString());
                        break;
                    case 5:     //Copy a file
                        Console.Write("Filename: ");
                        input1=Console.ReadLine();
                        Console.Write("Copy to: ");
                        input2=Console.ReadLine();
                        File.Copy(input1,input2);
                        break;
                    case 6:     //Rename a file
                        Console.Write("Filename: ");
                        input1=Console.ReadLine();
                        Console.Write("New Filename: ");
                        input2=Console.ReadLine();
                        File.Move(input1,input2);
                        break;
                }   
            } while (menuItem!=0);
        }
    }
}
