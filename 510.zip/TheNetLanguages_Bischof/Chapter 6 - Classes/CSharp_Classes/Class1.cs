//Write to a log file sample application using C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Classes
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            RunCheckingAccount();
            Console.ReadLine();
        }
        static void RunCheckingAccount()
        {
            CCheckingAccount CheckingAccount = new CCheckingAccount();

            CheckingAccount.Deposit(500);
            CheckingAccount.WriteCheck(400);
            CheckingAccount.WriteCheck(75);                
            CheckingAccount.WriteCheck(50);                
            CheckingAccount.Dispose();
            CheckingAccount = null;
        }

        public class CCheckingAccount
        {
            static double MinimumBalance = 100;
            private double CurrentBalance;
            private System.IO.StreamWriter LogFile;
            //The constructor will open the file for output
            public CCheckingAccount()
            {
                LogFile = new System.IO.StreamWriter(@"C:\LogFile.txt");
            }
            //Deposit money into the checking account
            public void Deposit(double Amount)
            {
                CurrentBalance += Amount;
                LogFile.WriteLine("Deposited ${0}; New Balance is ${1}", 
                    Amount, CurrentBalance);
            }
            //Withdraw money from the checking account
            public void WriteCheck(double Amount)
            {
                //Check to make sure it isn't below zero
                if ((CurrentBalance - Amount) > 0)
                {
                    CurrentBalance -= Amount;
                    //Log that the transaction took place
                    LogFile.WriteLine("Withdrew ${0}; New Balance is ${1}",
                        Amount, CurrentBalance);        
                    if (CurrentBalance < MinimumBalance) 
                    {
                        //Log that they are below the minimum balance
                        LogFile.WriteLine("You are below the minimum " + 
                            "balance of ${0}", MinimumBalance);
                    }
                }
                else
                {
                    //Log that there wasn't enough funds
                    LogFile.WriteLine("Insufficient funds - ${0} was not " +
                        "withdrawn", Amount);
                }
            }
            public void Dispose()
            {
                LogFile.Close();
                GC.SuppressFinalize(this);
            }
            ~CCheckingAccount()
            {
                LogFile.Close();
            }
        }        
    }
}