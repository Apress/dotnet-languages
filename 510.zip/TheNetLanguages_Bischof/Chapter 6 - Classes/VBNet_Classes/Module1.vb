'Write to a log file sample application using VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Classes()
        Console.ReadLine()
    End Sub

    Public Sub Classes()
        Dim CheckingAccount As New CCheckingAccount()
        CheckingAccount.Deposit(500)
        CheckingAccount.Withdraw(400)
        CheckingAccount.Withdraw(75)
        CheckingAccount.Withdraw(50)
        CheckingAccount.Dispose()
        CheckingAccount = Nothing
    End Sub

    Public Class CCheckingAccount
        Shared MinimumBalance As Double = 100
        Private LogFile As IO.StreamWriter
        Private CurrentBalance As Double
        'The constructor will open the file for output
        Public Sub New()
            LogFile = New IO.StreamWriter("C:\Logfile.txt")
        End Sub
        'Deposit money into the checking account
        Public Sub Deposit(ByVal Amount As Double)
            CurrentBalance += Amount
            LogFile.WriteLine("Deposited ${0}; New Balance is ${1}", _
                Amount, CurrentBalance)
        End Sub
        'Withdraw money from the checking account
        Public Sub Withdraw(ByVal Amount As Double)
            'Check to make sure it isn't below zero
            If (CurrentBalance - Amount) >= 0 Then
                CurrentBalance -= Amount
                'Log that the transaction took place
                LogFile.WriteLine("Withdrew ${0}; New Balance is ${1}", _
                    Amount, CurrentBalance)
                'Check if the minimum balance was reached
                If CurrentBalance < MinimumBalance Then
                    'Log that it went below the minimum balance
                    LogFile.WriteLine("You are below the minimum balance " & _
                        "of ${0}", MinimumBalance)
                End If
            Else
                'Log that there wasn't enough funds
                LogFile.WriteLine("Insufficient funds - ${0} was not " & _
                    "withdrawn", Amount)
            End If
        End Sub
        Public Sub Dispose()
            LogFile.Close()
        End Sub
        Protected Overrides Sub Finalize()
            LogFile.Close()
        End Sub
    End Class
End Module
