//Copying a File sample application in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.IO;

namespace C_ExceptionHandling
{
    class Class1
	{
        static void Main(string[] args)
		{
		    bool finishedCopying = true;
            string SourceName="", DestinationName="";
            do 
		    {
                try
                {
                    //Override value in case it failed last time
                    finishedCopying = true;               
                    //Get the filenames and do the copy
                    Console.WriteLine("Enter source file: ");
                    SourceName = Console.ReadLine();
                    Console.WriteLine("Enter destination file: ");
                    DestinationName = Console.ReadLine();
                    CopyFile(SourceName, DestinationName);
                }
                catch (FileNotFoundException)
                {
                    Console.WriteLine("The source file was not found: " + 
                        SourceName);
                    //Prompt the user for the filename again
                    finishedCopying = false;
                }
                catch (InvalidHeaderException ex)
                {
                    Console.WriteLine(ex.Message);          
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected error: " + ex.Message);
                }
            } while (!finishedCopying);
            Console.WriteLine("File copying is finished");
            Console.ReadLine();
        }

        //Copy from one file to another file
        static void CopyFile(string SourceName, string DestinationName)
        {
            StreamReader sourceFile = null;
            StreamWriter destinationFile = null;
            FileStream destinationFileStream;
            bool destinationFileReady = false;
            int lineCount;
            string fileText;           
            //There is no error checking here because the calling procedure
            //is designed to handle the "File Not Found" error.
            //SourceName must be converted to string so that it isn't
            //mis-interpreted by the compiler as a Stream
            sourceFile = new StreamReader(SourceName.ToString());            
            //At this point anything that happens will involve open files.
            //Wrap everything in a try block to close the files when done
            try     
            {
                do
                {
                    try
                    {
                        //Open the destination file for output
                        destinationFileStream = new FileStream(DestinationName,
                            FileMode.CreateNew, FileAccess.Write);
                        destinationFile = new StreamWriter(destinationFileStream);
                        //File open succeeded
                        destinationFileReady = true;
                    }
                    catch (IOException)
                    {
                        //The file already exists, so delete it
                        File.Delete(DestinationName);
                    }
                } while (!destinationFileReady);

                //Both of the files are now open, so do the copy
                lineCount = int.Parse(sourceFile.ReadLine());
                destinationFile.WriteLine(lineCount);
                for (int currentLine = 1; currentLine <= lineCount; 
                    currentLine++)
                {
                    fileText = sourceFile.ReadLine();
                    if (fileText == null)
                    {
                        throw new InvalidHeaderException();
                    }
                    destinationFile.WriteLine(fileText);
                }
            }               
            //There is no catch block so that all unhandled errors will 
            //be passed to the calling procedure   
            finally
            {
                //close any open files
                if (sourceFile != null)
                {
                    sourceFile.Close();
                }
                if (destinationFile != null)
                {
                    destinationFile.Close();
                }
            }    
        }               
    }

    //Custom exception class to handle a bad header record
    public class InvalidHeaderException : ApplicationException
    {
            public InvalidHeaderException()
            : this("")
            {}
            public InvalidHeaderException(string message)
            : base("Source file had invalid header." + message)
            {}
    }
}
