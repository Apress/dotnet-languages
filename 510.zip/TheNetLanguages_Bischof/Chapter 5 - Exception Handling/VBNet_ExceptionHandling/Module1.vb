'Copying a File sample application in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.IO

Module Module1

    Sub Main()
        Dim finishedCopying As Boolean = True
        Dim sourceName, destinationName As String
        Do
            Try
                'Override value in case it failed last time
                finishedCopying = True
                'Get the filenames and do the copy
                Console.WriteLine("Enter source file: ")
                sourceName = Console.ReadLine()
                Console.WriteLine("Enter destination file: ")
                destinationName = Console.ReadLine()
                CopyFile(sourceName, destinationName)
            Catch ex As FileNotFoundException
                Console.WriteLine("The source file was not found: " + _
                    sourceName)
                'Prompt the user for the filename again
                finishedCopying = False
            Catch ex As InvalidHeaderException
                Console.WriteLine(ex.Message)
            Catch ex As Exception
                Console.WriteLine("Unexpected error: " + ex.Message)
            End Try
        Loop While (Not finishedCopying)
        Console.WriteLine("File copying is finished")
        Console.ReadLine()
    End Sub

    'Copy from one file to another file
    Private Sub CopyFile(ByVal SourceName As String, ByVal DestinationName _
        As String)
        Dim sourceFile As StreamReader = Nothing
        Dim destinationFile As StreamWriter = Nothing
        Dim destinationFileStream As FileStream
        Dim destinationFileReady As Boolean
        Dim lineCount As Integer
        Dim fileText As String
        Dim currentLine As Integer
        'There is no error checking here because the calling procedure
        'is designed to handle the "File Not Found" error.
        'sourceName must be converted to string so that it isn't
        'mis-interpreted by the compiler as a Stream
        sourceFile = New StreamReader(SourceName.ToString())
        'At this point anything that happens will involve open files.
        'Wrap everything in a try block to close the files when done
        Try
            Do
                Try
                    'Open the destination file for output
                    destinationFileStream = New FileStream(DestinationName, _
                        FileMode.CreateNew, FileAccess.Write)
                    destinationFile = New StreamWriter(destinationFileStream)
                    'File open succeeded
                    destinationFileReady = True
                Catch
                    'The file already exists, so delete it
                    File.Delete(DestinationName)
                End Try
            Loop While (Not destinationFileReady)
            'Both of the files are now open, so do the copy
            lineCount = Integer.Parse(sourceFile.ReadLine())
            destinationFile.WriteLine(lineCount)
            For currentLine = 1 To lineCount
                fileText = sourceFile.ReadLine()
                If (fileText = Nothing) Then
                    Throw New InvalidHeaderException()
                End If
                destinationFile.WriteLine(fileText)
            Next
        'There is no catch block so that all unhandled errors will 
        'be passed to the calling procedure
        Finally
            'close any open files
            If (Not sourceFile Is Nothing) Then
                sourceFile.Close()
            End If
            If (Not destinationFile Is Nothing) Then
                destinationFile.Close()
            End If
        End Try
    End Sub

    'Custom exception class to handle a bad header record
    Public Class InvalidHeaderException
        Inherits ApplicationException
            Public Sub New()
                Me.New("")
            End Sub
            Public Sub New(ByVal message As String)
                MyBase.New("Source file had invalid header." + message)
            End Sub
    End Class
End Module
