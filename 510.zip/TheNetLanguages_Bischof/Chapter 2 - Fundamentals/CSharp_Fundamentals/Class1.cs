//Calculate Test Scores sample application using C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Fundamentals_TestScores
{
    class Class1
    {
        static void Main(string[] args)
        {
            ProcessScores(80, 90, 75);
            Console.ReadLine();
        }

        static public void ProcessScores(int Score1, int Score2, int Score3)
        {
            int highScore;
            float avgScore;
            //Write the scores we are working with
            DisplayScores(Score1, Score2, Score3);        
            //Get the high score
            CalcHighScore(Score1, Score2, Score3, out highScore);
            Console.WriteLine("The high score is {0}", highScore);            
            //Get the average score
            avgScore = CalcAvgScore(Score1, Score2, Score3);
            Console.WriteLine("The average score is {0:N2}", avgScore);
        }

        //Display all scores using a parameter array
        static internal void DisplayScores(params int[] Scores)
        {
            Console.Write("The scores being used are: ");
            for (int currentScore = 0; currentScore < Scores.Length; currentScore++)
            {
                Console.Write(Scores[currentScore] + "  ");
            }
            Console.WriteLine();
        }

        //Use an out parameter to return the high score
        static private void CalcHighScore(int Score1, int Score2, int Score3, out int highScore)
        {
            //Assume Score1 is the high score
            highScore=Score1;
            //Is Score2 higher?
            if (Score2 > Score1)
            {
                highScore = Score2;
            }
            //Does Score3 beat them all?
            if (Score3 > highScore)
            {
                highScore = Score3;
            }
        }
        
        //Use a function to calculate the average score
        static private float CalcAvgScore(params int[] Scores)
        {
            int totalScore=0;
            for (int currentScore = 0; currentScore < Scores.Length; currentScore++)
            {
                totalScore += Scores[currentScore];
            }
            return totalScore/(float)Scores.Length;
        }        
    }
}
