'Calculate Test Scores sample application using VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        ProcessScores(80, 90, 75)
        Console.ReadLine()
    End Sub

    Public Sub ProcessScores(ByVal Score1 As Integer, ByVal Score2 As Integer, _
        ByVal Score3 As Integer)
        Dim highScore As Integer
        Dim avgScore As Single
        'Write the scores we are working with
        DisplayScores(Score1, Score2, Score3)
        'Get the high score
        CalcHighScore(Score1, Score2, Score3, highScore)
        Console.WriteLine("The high score is {0}", highScore)
        'Get the average score
        avgScore = CalcAvgScore(Score1, Score2, Score3)
        Console.WriteLine("The average score is {0:N2}", avgScore)
    End Sub

    'Display all scores using a parameter array
    Private Sub DisplayScores(ByVal ParamArray Scores() As Integer)
        Dim currentScore As Integer
        Console.Write("The scores being used are: ")
        For currentScore = 0 To Scores.Length - 1
            Console.Write(Scores(currentScore).ToString & "  ")
        Next
        Console.WriteLine()
    End Sub

    'Use an out parameter to return the high score
    Private Sub CalcHighScore(ByVal Score1 As Integer, ByVal Score2 As Integer, _
        ByVal Score3 As Integer, ByRef HighScore As Integer)
        'Assume score1 is the high score
        HighScore = Score1
        'Is Score2 higher?
        If (Score2 > Score1) Then
            HighScore = Score2
        End If
        'Does Score3 beat them all?
        If (Score3 > HighScore) Then
            HighScore = Score3
        End If
    End Sub

    'Use a function to calculate the average score
    Private Function CalcAvgScore(ByVal ParamArray Scores() As Integer) As Single
        Dim TotalScore, CurrentScore As Integer
        For CurrentScore = 0 To Scores.Length - 1
            TotalScore += Scores(CurrentScore)
        Next
        Return CSng(TotalScore / Scores.Length)
    End Function
End Module
