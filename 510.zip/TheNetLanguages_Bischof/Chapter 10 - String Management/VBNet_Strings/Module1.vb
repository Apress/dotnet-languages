'Manipulating and input string using VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Dim menuItem, startPos, numChars As Integer
        Dim myString, input1, input2 As String
        Console.WriteLine("String Management Functions")
        Do
            Console.WriteLine()
            Console.WriteLine("Current String: {0}", myString)
            Console.WriteLine("1. Enter new string")
            Console.WriteLine("2. Replace text")
            Console.WriteLine("3. Remove text")
            Console.WriteLine("4. Convert to upper case")
            Console.WriteLine("5. Convert to lower case")
            Console.WriteLine("0. Exit")
            Console.Write("Selection: ")
            menuItem = Integer.Parse("0" & Console.ReadLine())
            Select Case (menuItem)
                Case 1 'Enter a new string
                    Console.Write("Enter new string: ")
                    myString = Console.ReadLine()
                Case 2 'Replace characters
                    Console.Write("Text to replace: ")
                    input1 = Console.ReadLine()
                    Console.Write("New text: ")
                    input2 = Console.ReadLine()
                    myString = myString.Replace(input1, input2)
                Case 3 'Remove text
                    Console.Write("Text to remove: ")
                    input1 = Console.ReadLine()
                    'Find the starting position
                    startPos = myString.IndexOf(input1)
                    If (startPos >= 0) Then
                        numChars = input1.Length
                        'Remove the characters at the starting position
                        myString = myString.Remove(startPos, numChars)
                    End If
                Case 4 'Convert to uppercase
                    myString = myString.ToUpper()
                Case 5     'Convert to lowercase
                    myString = myString.ToLower()
            End Select
        Loop While (menuItem <> 0)
    End Sub
End Module
