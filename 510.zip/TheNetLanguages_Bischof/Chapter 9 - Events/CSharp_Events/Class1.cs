//Managing a checking account in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Events
{
	class Class1
	{
		static void Main(string[] args)
		{
            //Create the object instance
            //Set the event reference for the TransactionAlert() method
            CCheckingAccount CheckingAccount = new CCheckingAccount(100);
            CheckingAccount.TransactionMessage += 
                new CCheckingAccount.AccountMessageHandler(TransactionAlert);
            //Process transactions on the account
            CheckingAccount.Deposit(500);
            CheckingAccount.Withdraw(400);
            CheckingAccount.Withdraw(75);				
            CheckingAccount.Withdraw(50);				
            Console.ReadLine();
        }

        static void TransactionAlert(object sender, string Message)
        {
            Console.WriteLine(Message);
        }
        
		public class CCheckingAccount
		{
			public delegate void AccountMessageHandler(object sender, 
                string message);
			public event AccountMessageHandler TransactionMessage;
			private double CurrentBalance;
			private double MinimumBalance;

			public CCheckingAccount(double MinimumBalance)
			{
				this.MinimumBalance = MinimumBalance;
			}
			public double Balance
			{
				get
				{
					return CurrentBalance;
				}
			}			
            //Deposit money into the checking account
            public void Deposit(double Amount)
            {
                CurrentBalance += Amount;
                //Tell the user that the deposit was made
                TransactionMessage(this, String.Format("Deposited ${0}; " +
                    "New Balance is ${1}", Amount, CurrentBalance));
            }
                //Withdraw money from the checking account
			public void Withdraw(double Amount)
			{
				//Check to make sure it isn't below zero
				if ((CurrentBalance - Amount) > 0) 
				{
					CurrentBalance -= Amount;
					//Tell the user that the transaction took place
					Console.WriteLine("Withdrew ${0}; New Balance is ${1}",
                        Amount, CurrentBalance);           
					//Check if the minimum balance was reached
					if (CurrentBalance < MinimumBalance)
					{
                        //Raise the event that they are below the minimum balance
						TransactionMessage(this, "Warning: You are below the " + 
                            "minimum balance of $" + MinimumBalance + ".");
					}
				}
				else
				{
					//Raise the event that there wasn't enough funds
					TransactionMessage(this, "Insufficient Funds: $" + Amount +
                        " dollars was not withdrawn.");
				}
			}
		}			
	}
}
