'Managing a checking account in VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1
    'Declare the class so that it can recognize the events
    Private WithEvents CheckingAccount As CCheckingAccount

    Sub Main()
        CheckingAccount = New CCheckingAccount(100)
        'Subscribe to the Alert event
        AddHandler CheckingAccount.Alert, AddressOf TransactionAlert
        CheckingAccount.Deposit(500)
        CheckingAccount.Withdraw(400)
        CheckingAccount.Withdraw(75)
        CheckingAccount.Withdraw(50)
        Console.ReadLine()
    End Sub

    'Handle the CheckingAccount.Alert event
    Private Sub TransactionAlert(ByVal sender As Object, _
        ByVal Message As String)
        Console.WriteLine("Alert! {0}", message)
    End Sub

    'Subscribe to the Confirmation event and handle it
    Private Sub TransactionConfirmation(ByVal sender As Object, _
        ByVal message As String) Handles CheckingAccount.Confirmation
        Console.WriteLine(message)
    End Sub

    Public Class CCheckingAccount
        'Declare the events that will be used
        Public Event Confirmation(ByVal sender As Object, _
            ByVal Message As String)
        Public Event Alert(ByVal sender As Object, ByVal Message As String)
        Private CurrentBalance As Double
        Private MinimumBalance As Double

        Public Sub New(ByVal MinimumBalance As Double)
            Me.MinimumBalance = MinimumBalance
        End Sub

        Public ReadOnly Property Balance(ByVal CurrentBalance As Double) _
            As Double
            Get
                Return Me.CurrentBalance
            End Get
        End Property

        'Deposit money into the checking account
        Public Sub Deposit(ByVal Amount As Double)
            CurrentBalance += Amount
            'Tell the user that the deposit was made
            RaiseEvent Confirmation(Me, String.Format("Deposited ${0}; " & _
                "New Balance is ${1}", Amount, CurrentBalance))
        End Sub

        'Withdraw money from the checking account
        Public Sub Withdraw(ByVal Amount As Double)
            'Check to make sure it isn't below zero
            If (CurrentBalance - Amount) >= 0 Then
                CurrentBalance -= Amount
                'Tell the user that the withdrawal was made
                RaiseEvent Confirmation(Me, String.Format("Withdrew ${0}; " & _
                    "New Balance is ${1}", Amount, CurrentBalance))
                'Check if the minimum balance was reached
                If CurrentBalance < MinimumBalance Then
                    'Raise the event that it went below the minimum balance
                    RaiseEvent Alert(Me, String.Format("You are below the " & _
                        "minimum balance of ${0}", MinimumBalance))
                End If
            Else
                'Raise the event that there wasn't enough funds
                RaiseEvent Alert(Me, String.Format("Insufficient funds: " & _
                    "${0} was not withdrawn", Amount))
            End If
        End Sub
    End Class
End Module
