'Displaying application information in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.Reflection
Imports System.Diagnostics

Module Module1
    Sub Main()
        'Define the class that gets application info
        Dim fileInfo As FileVersionInfo
        'Define the misc info variables
        Dim fileLocation, fileName, verFull As String
        Dim verMajor, verMinor, verBuild, verPrivate As Integer
        'Get the file location string
        'Note: Assembly is enclosed in brackets b/c it is a reserved word
        fileLocation = [Assembly].GetExecutingAssembly().Location
        'Get the file information object
        fileInfo = FileVersionInfo.GetVersionInfo(fileLocation)
        'Get the various file details
        fileName = fileInfo.OriginalFilename
        verFull = fileInfo.FileVersion
        verMajor = fileInfo.FileMajorPart
        verMinor = fileInfo.FileMinorPart
        verBuild = fileInfo.FileBuildPart
        verPrivate = fileInfo.FilePrivatePart
        'Display all the details
        Console.WriteLine("File name        : {0}", fileName)
        Console.WriteLine("Full filepath    : {0}", fileLocation)
        Console.WriteLine("Version number   : {0}", verFull)
        Console.WriteLine("Major part       : {0}", verMajor)
        Console.WriteLine("Minor part       : {0}", verMinor)
        Console.WriteLine("Build part       : {0}", verBuild)
        Console.WriteLine("Private part     : {0}", verPrivate)
        Console.ReadLine()
    End Sub
End Module
