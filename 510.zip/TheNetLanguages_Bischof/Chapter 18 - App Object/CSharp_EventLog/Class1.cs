//Logging errors using the event log in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.Diagnostics;

namespace Event_Log
{
    class Class1
    {
        static void Main(string[] args)
        {
            int x=0, y=0;
            try
            {
                x /= y;
            }
            catch (Exception e)
            {
                LogError(e, "I knew this wouldn't work!", true);
            }
        }

        //Standard error logging procedure
        static void LogError(Exception e, string MoreInfo, bool Trace)
        {
            string errMessage;
            //Create the EventLog object
            EventLog log = new EventLog();
            //Create the error message
            errMessage = e.Message;
            if (MoreInfo != "")
            {
                errMessage += ", More Info: " + MoreInfo;
            }
            if (Trace) 
            {
                errMessage += ", StackTrace:" + e.StackTrace;
            }
            //Set the EventLog properties
            log.Log = "Application";
            log.Source = e.Source;
            //Write the entry
            log.WriteEntry(errMessage);
            //Close the log file
            log.Close();
        }
    }        
}
