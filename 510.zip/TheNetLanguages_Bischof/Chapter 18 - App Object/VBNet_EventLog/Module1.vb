'Logging errors using the event log in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.Diagnostics

Module Module1

    Sub Main()
        Dim x, y As Integer
        Try
            x /= y
        Catch e As Exception
            LogError(e, "I knew this wouldn't work!", True)
        End Try
    End Sub

    'Standard error logging procedure
    Sub LogError(ByVal e As Exception, ByVal MoreInfo As String, _
        ByVal Trace As Boolean)
        Dim errMessage As String
        'Create the EventLog object
        Dim log As EventLog = New EventLog()
        'Create the error message
        errMessage = e.Message
        If MoreInfo <> "" Then
            errMessage += ", More Info: " + MoreInfo
        End If
        If Trace Then
            errMessage += ", StackTrace:" + e.StackTrace
        End If
        'Set the EventLog properties
        log.Log = "Application"
        log.Source = e.Source
        'Write the entry
        log.WriteEntry(errMessage)
        'Close the log file
        log.Close()
    End Sub
End Module
