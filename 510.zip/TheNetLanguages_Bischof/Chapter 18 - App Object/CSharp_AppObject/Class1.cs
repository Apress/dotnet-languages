//Displaying application information in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.Reflection;
using System.Diagnostics;

namespace C_AppObject
{
    class Class1
    {
        static void Main(string[] args)
        {
            //Define the class that gets application info
            FileVersionInfo fileInfo;
            //Define the misc info variables
            string fileLocation, fileName, verFull;
            int verMajor, verMinor, verBuild, verPrivate;
            //Get the file location string
            fileLocation = Assembly.GetExecutingAssembly().Location;
            //Get the file information object
            fileInfo = FileVersionInfo.GetVersionInfo(fileLocation);
            //Get the various file details
            fileName = fileInfo.OriginalFilename;
            verFull = fileInfo.FileVersion;
            verMajor = fileInfo.FileMajorPart;
            verMinor = fileInfo.FileMinorPart;
            verBuild = fileInfo.FileBuildPart;
            verPrivate = fileInfo.FilePrivatePart;
            //Display all the details
            Console.WriteLine("File name        : {0}", fileName);
            Console.WriteLine("Full filepath is : {0}", fileLocation);
            Console.WriteLine("Version number   : {0}", verFull);
            Console.WriteLine("Major part       : {0}", verMajor);
            Console.WriteLine("Minor part       : {0}", verMinor);
            Console.WriteLine("Build part       : {0}", verBuild);
            Console.WriteLine("Private part     : {0}", verPrivate);
            Console.ReadLine();
        }
    }
}