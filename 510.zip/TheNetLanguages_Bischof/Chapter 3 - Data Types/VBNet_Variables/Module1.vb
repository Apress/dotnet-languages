'Declaring and Using Variables in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1
    Sub Main()
        ProcessScript("D1,Btrue,bfalse,I4453")
        Console.ReadLine()
    End Sub

    Private Sub ProcessScript(ByVal Script As String)
        'Declare an array and automatically populate its values
        Dim DaysOfMonth() As Integer = New Integer() {31, 28, 31, 30, 31, _
            30, 31, 31, 30, 31, 30, 31}
        'Both date variables are declared as a Date
        Dim FirstDate, LastDate As Date
        Dim IntegerData As Integer, StringData As String, BooleanData As _
            Boolean
        Dim Command As Char
        Dim Scripts() As String
        Dim ScriptCount As Integer
        If Not Script = "" Then
            Console.WriteLine("The script is: {0}", Script)
            'Split the string into a string array using a comma seperator
            Scripts = Script.Split(","c)
            For ScriptCount = 0 To UBound(Scripts)
                Command = Scripts(ScriptCount).ToUpper.Chars(0)
                StringData = Scripts(ScriptCount).Substring(1)
                Select Case Command
                    Case "B"c        'Boolean
                        If StringData.ToUpper = "TRUE" Then
                            BooleanData = True
                        Else
                            BooleanData = False
                        End If
                        Console.WriteLine(BooleanData.ToString)
                    Case "D"c        'Date
                        FirstDate = CDate(StringData & "/1/" & Today.Year())
                        LastDate = CDate(StringData & "/" & DaysOfMonth( _
                            CInt(StringData) - 1) & "/" & Today.Year())
                        Console.WriteLine("Beginning of Month: {0}", _
                            FirstDate.ToShortDateString)
                        Console.WriteLine("End of Month: {0}", _
                            LastDate.ToShortDateString)
                    Case "I"c        'Integer
                        IntegerData = CInt(StringData)
                        Console.WriteLine(IntegerData)
                End Select
            Next
        End If
    End Sub
End Module
