'Comparing Boolean Operators in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Comparisons(False, True)
        Comparisons(True, False)
        Console.ReadLine()
    End Sub

    'Show how each logical operator works on two boolean variables
    Private Sub Comparisons(ByVal Condition1 As Boolean, ByVal Condition2 _
        As Boolean)
        Console.WriteLine("Conditions Tested: {0}, {1}", _
            Condition1.ToString, Condition2.ToString)
        'Test the And operator
        Console.WriteLine("Operator: And")
        If FirstComparison(Condition1) And SecondComparison(Condition2) Then
            Console.WriteLine("  Result: True")
        Else
            Console.WriteLine("  Result: False")
        End If
        'Test the AndAlso operator
        Console.WriteLine("Operator: AndAlso")
        If FirstComparison(Condition1) AndAlso _
            SecondComparison(Condition2) Then
            Console.WriteLine("  Result: True")
        Else
            Console.WriteLine("  Result: False")
        End If
        'Test the Or operator
        Console.WriteLine("Operator: Or")
        If FirstComparison(Condition1) Or SecondComparison(Condition2) Then
            Console.WriteLine("  Result: True")
        Else
            Console.WriteLine("  Result: False")
        End If
        'Test the OrAlso operator
        Console.WriteLine("Operator: OrElse")
        If FirstComparison(Condition1) OrElse _
            SecondComparison(Condition2) Then
            Console.WriteLine("  Result: True")
        Else
            Console.WriteLine("  Result: False")
        End If
        Console.WriteLine("---------------")
        Console.WriteLine()
    End Sub

    'Show that the first comparison was performed
    Private Function FirstComparison(ByVal Condition As Boolean) As Boolean
        Console.WriteLine("  First Comparison is: {0}", Condition.ToString)
        Return Condition
    End Function

    'Show that the second comparison was performed
    Private Function SecondComparison(ByVal Condition As Boolean) As Boolean
        Console.WriteLine("  Second Comparison is: {0}", Condition.ToString)
        Return Condition
    End Function
End Module
