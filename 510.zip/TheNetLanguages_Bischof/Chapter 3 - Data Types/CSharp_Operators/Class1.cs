//Comparing Boolean Operators in VB.Net
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_DataTypes_Operators
{
	class Class1
	{
		static void Main(string[] args)
		{
            Comparisons(false, true);
            Comparisons(true, false);
            Console.ReadLine();
		}
        private static void Comparisons(bool condition1, bool condition2)
        {
            Console.WriteLine("Conditions Tested: {0}, {1}", 
                condition1.ToString(), condition2.ToString());
            //Test the & operator
            Console.WriteLine("Operator: &");           
            if (FirstComparison(condition1) & SecondComparison(condition2))
            {
                Console.WriteLine("  Result: True");
            }
            else
            {
                Console.WriteLine("  Result: False");
            }
            //Test the && operator
            Console.WriteLine("Operator: &&");           
            if (FirstComparison(condition1) && SecondComparison(condition2))
            {
                Console.WriteLine("  Result: True");
            }
            else
            {
                Console.WriteLine("  Result: False");
            }
            //Test the | operator
            Console.WriteLine("Operator: |");            
            if (FirstComparison(condition1) | SecondComparison(condition2))
            {
                Console.WriteLine("  Result: True");
            }
            else
            {
                Console.WriteLine("  Result: False");
            }
            //Test the || operator
            Console.WriteLine("Operator: ||");            
            if (FirstComparison(condition1) || SecondComparison(condition2))
            {
                Console.WriteLine("  Result: True");
            }
            else
            {
                Console.WriteLine("  Result: False");
            }
            Console.WriteLine("---------------");
            Console.WriteLine();
        }

        //Show that the first comparison was performed
        private static bool FirstComparison(bool condition)
        {
            Console.WriteLine("  First Comparison is: {0}", 
                condition.ToString());
            return condition;
        }

        //Show that the second comparison was performed
        private static bool SecondComparison(bool condition)
        {   
            Console.WriteLine("  Second Comparison is: {0}", 
                condition.ToString());
            return condition;
        }
    }
}
