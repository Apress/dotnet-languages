//Using Enumerators to Print Employee Info in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Enum
{
    class Class1
    {
        [Flags] enum EmpRecord
        {   //The "0x" prefix specifies a hexidecimal constant
            Staff = 0x01,
            Manager = 0x02,
            Accounting = 0x04,
            Advertising = 0x08
        }
        static void Main(string[] args)
        {
            EmpRecord employee;
            //Create a variable representing a manager in the accounting dept.
            //Use a binary OR to add them together
            employee= EmpRecord.Manager | EmpRecord.Accounting;
            //Display that person's information
            ShowInfo("Joe Jones", employee);
            //Create a variable representing a manager in the accounting dept.
            //Use a binary OR to add them together
            employee = EmpRecord.Staff | EmpRecord.Advertising;
            //Display that person's information
            ShowInfo("Mary Jane", employee);       
            Console.ReadLine();
        }
        static void ShowInfo(string Name, EmpRecord Employee)
        {   
            EmpRecord position, department;
            EmpRecord allPositions, allDepartments;
            //Use a binary OR to get the bits that represent a 
            //Position or Department
            allPositions = EmpRecord.Staff | EmpRecord.Manager;
            allDepartments = EmpRecord.Accounting | EmpRecord.Advertising;
            //Use binary AND to filter out the bits in the other area
            position = Employee & allPositions;
            department = Employee & allDepartments;
            //Print out the name and the employee info
            Console.WriteLine();
            Console.WriteLine("Employee: {0}", Name);
            Console.Write("Position: ");
            Console.WriteLine(position.ToString());
            Console.Write("Department: ");
            Console.WriteLine(department.ToString());
        }        
    }
}
