'Using Enumerators to Print Employee Info in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1
    <Flags()> Enum EmpRecord
        'The "&H" prefix specifies a hexidecimal constant
        Staff = &H1
        Manager = &H2
        Accounting = &H4
        Advertising = &H8
    End Enum

    Sub Main()
        Dim employee As EmpRecord
        'Create a variable representing a manager in the accounting dept.
        'Use a binary OR to add them together
        employee = EmpRecord.Manager Or EmpRecord.Accounting
        'Display that person's information
        ShowInfo("Joe Jones", employee)
        'Create a variable representing a manager in the accounting dept.
        'Use a binary OR to add them together
        employee = EmpRecord.Staff Or EmpRecord.Advertising
        'Display that person's information
        ShowInfo("Mary Jane", employee)
        Console.ReadLine()
    End Sub

    Sub ShowInfo(ByVal Name As String, ByVal Employee As EmpRecord)
        Dim position, department As EmpRecord
        Dim allPositions, allDepartments As EmpRecord
        'Get all the bits that only represent a Position or Department
        allPositions = EmpRecord.Staff Or EmpRecord.Manager
        allDepartments = EmpRecord.Accounting Or EmpRecord.Advertising
        'Use a binary OR to get the bits that represent a 
        'Position or Department
        position = Employee And allPositions
        department = Employee And allDepartments
        'Print out the name and the employee info
        Console.WriteLine()
        Console.WriteLine("Employee: {0}", Name)
        Console.Write("Position: ")
        Console.WriteLine(position.ToString())
        Console.Write("Department: ")
        Console.WriteLine(department.ToString())
    End Sub
End Module