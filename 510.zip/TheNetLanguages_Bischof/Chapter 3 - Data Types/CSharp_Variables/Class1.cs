//Declaring and Using Variables in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_DataTypes_Variables
{
    class Class1
    {
        static void Main(string[] args)
        {
            ProcessScript("D1,Btrue,bfalse,I4453");
            Console.ReadLine();
        }

        [STAThread]
        private static void ProcessScript(string Script)
        {
            //Declare an array and automatically populate its values
            int[] daysOfMonth = new int[] {31, 28, 31, 30, 31, 30, 31, 31, 30,
                                           31, 30, 31};
            //Both date variables are declared as a DateTime
            DateTime firstDate, lastDate;   
            int integerData; 
            string stringData; 
            bool booleanData;
            char command;
            string[] scripts;
            int scriptCount;

            if (Script != "")
            {
                Console.WriteLine("The script is: {0}", Script);
                //Split the string into a string array based upon the comma
                //seperator
                scripts = Script.Split(',');
                for (scriptCount = 0; scriptCount < scripts.Length; 
                    scriptCount++)
                {
                    command = char.Parse(scripts[scriptCount].Substring(0,1).
                        ToUpper());
                    stringData = scripts[scriptCount].Substring(1);
                    switch(command){
                        case 'B':        //Boolean
                            if (stringData.ToUpper() == "TRUE")
                            {
                                booleanData = true;
                            }
                            else
                            {
                                booleanData = false;
                            }
                            Console.WriteLine("{0}",booleanData.ToString());
                            break;
                        case 'D':        //Date
                            firstDate = DateTime.Parse(stringData + "/1/" + 
                                DateTime.Today.Year);
                            lastDate = DateTime.Parse(stringData + "/"
                                + daysOfMonth[int.Parse(stringData) - 1] 
                                + "/" + DateTime.Today.Year);
                            Console.WriteLine("Beginning of Month: {0}",
                                firstDate.ToShortDateString());
                            Console.WriteLine("End of Month: {0}", 
                                lastDate.ToShortDateString());
                            break;
                        case 'I':        //Integer
                            integerData = int.Parse(stringData);
                            Console.WriteLine(integerData);
                            break;
                    } //switch
                } //for
            } //if
        } //ProcessScript
    } //class
}
