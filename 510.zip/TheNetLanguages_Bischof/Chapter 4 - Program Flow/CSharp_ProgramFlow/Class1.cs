//Logging in a user in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_ProgramFlow
{
    class Class1
    {
        static void Main(string[] args)
        {
            string userId = "", password;
            int userIdIndex, currentNumber;
            int firstDigit;
            System.Collections.Hashtable numbers = new 
                System.Collections.Hashtable();           
            //Initialize the numbers collection
            numbers.Add(0, "Zero"); numbers.Add(1, "One"); 
            numbers.Add(2, "Two"); numbers.Add(3, "Three");  
            numbers.Add(4, "Four"); numbers.Add(5, "Five"); 
            numbers.Add(6, "Six"); numbers.Add(7, "Seven"); 
            numbers.Add(8, "Eight"); numbers.Add(9, "Nine");
            //Get the user id using the While...End While loop
            while (userId.Length <= 3)
            {
                Console.WriteLine("Please enter user id that is more " + 
                    "than 3 digits");
                userId = Console.ReadLine();
                //Test the user id length using an If Then statement
                if (userId.Length == 0)
                    Console.WriteLine("You didn't enter a user id");
                else if (userId.Length <= 3)
                    Console.WriteLine("You didn't enter more than 3 digits");
                else
                    Console.WriteLine("User id was entered successfully");  
            }
            //Get the password using the Do...While loop
            do
            {
                Console.WriteLine("Please enter a password " + 
                    "(Hint: it's Delphi)");
                password = Console.ReadLine();
            } while (password != "Delphi");
            //Display the user's employee level using the first number 
            //in the user id
            firstDigit = int.Parse(userId.Substring(0,1));
            switch (firstDigit)
            {
                case 1:
                case 2:
                case 3:
                    Console.WriteLine("You are a hard working Staff person");
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                    Console.WriteLine("It's always good to have " + 
                        "management logging in");
                    break;
                case 9:
                    Console.WriteLine("Hey, it's the big shot");
                    break;
                default:
                    Console.WriteLine("Invalid user id.");
                    break;
            }
            //Loop through the user id and display the text equivalants 
            //of the number
            Console.WriteLine("Your user id numbers are:");
            for (userIdIndex = 0; userIdIndex < userId.Length; userIdIndex++)
            {
                //Get the first digit of the user id
                currentNumber = int.Parse(userId.Substring(userIdIndex,1));
                //Use a For Each loop to find the number that matches
                foreach (System.Collections.DictionaryEntry numberElement 
                             in numbers)
                {
                    if (currentNumber.Equals(numberElement.Key)) 
                    {    
                        Console.WriteLine(numberElement.Value);                 
                    }
                }
            }             
            Console.ReadLine();
        }
    }
}
