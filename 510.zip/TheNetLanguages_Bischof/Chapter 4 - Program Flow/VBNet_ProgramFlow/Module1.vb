'Logging in a user in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Dim userId As String = "", password As String
        Dim userIdIndex As Integer, currentNumber As Integer
        Dim firstDigit As Integer
        Dim numbers As New Collections.Hashtable()
        Dim numberElement As DictionaryEntry
        'Initialize the numbers collection
        numbers.Add(0, "Zero") : numbers.Add(1, "One")
        numbers.Add(2, "Two") : numbers.Add(3, "Three")
        numbers.Add(4, "Four") : numbers.Add(5, "Five")
        numbers.Add(6, "Six") : numbers.Add(7, "Seven")
        numbers.Add(8, "Eight") : numbers.Add(9, "Nine")
        'Get the user id using the While...End While loop
        While (userId.Length <= 3)
            Console.WriteLine("Please enter user id that is more than 3 digits")
            userId = Console.ReadLine()
            'Test the user id length using an If Then statement
            If userId.Length = 0 Then
                Console.WriteLine("You didn't enter a user id")
            ElseIf userId.Length <= 3 Then
                Console.WriteLine("You didn't enter more than 3 digits")
            Else
                Console.WriteLine("User id was entered successfully")
            End If
        End While
        'Get the password using the Do...Loop Until 
        Do
            Console.WriteLine("Please enter a password (Hint: it's Delphi)")
            password = Console.ReadLine()
        Loop Until password = "Delphi"
        'Display the user's employee level using the first number in the user id
        firstDigit = Integer.Parse(userId.Chars(0))
        Select Case firstDigit
            Case Is <= 3
                Console.WriteLine("You are a hard working Staff person")
            Case 4 To 8
                Console.WriteLine("It's always good to have management " & _
                    "logging in")
            Case 9
                Console.WriteLine("Hey, it's the big shot")
            Case Else
                Console.WriteLine("Invalid user id.")
        End Select
        'Loop through the user id and display the text equivalants of the number
        Console.WriteLine("Your user id numbers are:")
        For userIdIndex = 0 To userId.Length - 1
            'Get the first digit of the user id
            currentNumber = Integer.Parse(userId.Chars(userIdIndex))
            'Use a For Each loop to find the number that matches
            For Each numberElement In numbers
                If currentNumber.Equals(numberElement.Key) Then
                    Console.WriteLine(numberElement.Value)
                End If
            Next
        Next
        Console.ReadLine()
    End Sub
End Module
