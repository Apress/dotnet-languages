//A RegEditor class in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using Microsoft.Win32;

namespace C_Registry
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            RegEditor regEdit;    
            string keyName = "Best Sellers";
            string keyData = "The .Net Languages: A Quick Translation Guide";
            string newData;
            //Tell the user the what key we are going to write
            Console.WriteLine("Writing to Registry");
            Console.WriteLine("Key Name :{0}", keyName);
            Console.WriteLine("Key Value:{0}", keyData);
            //Instantiate the custom registry editor
            regEdit = new RegEditor(@"SOFTWARE/Apress");
            //Write the string to the registry key
            regEdit.SetValue(keyName, keyData);
            //Read it back to a new variable to check if it worked            
            newData = regEdit.GetValue(keyName);
            Console.WriteLine("Reading from the Registry");
            Console.WriteLine("Key Value:{0}", newData);
            //We're done, so delete it
            Console.WriteLine("Deleting it...");
            regEdit.DeleteValue(keyName);
            newData = regEdit.GetValue(keyName);
            Console.WriteLine("Key Value:{0}", newData);
            Console.WriteLine("Done");
            Console.ReadLine();
        }
    }

    //This class will write keys to a specified path in the registry tree.
    //It is designed to work with the HKey_Local_Machine
    class RegEditor
    {
        private RegistryKey regKey;
        //Constructor needs the registry path
        public RegEditor(string RegPath)
        {
            regKey = GetRegistryKey(RegPath);
        }
        //Write a value to the registry
        public void SetValue(string KeyName, object KeyValue)
        {
            regKey.SetValue(KeyName, KeyValue);
        }
        //Get a value from the registry - return strings for simplicity sake
        public string GetValue(string KeyName)
        {
            return (string)regKey.GetValue(KeyName);
        }
        //Delete the value key
        public void DeleteValue(string KeyName)
        {
            regKey.DeleteValue(KeyName);
        }
        //Take a registry key path and get the key associated with it
        private RegistryKey GetRegistryKey(string RegPath)
        {
            RegistryKey regKey;
            string[] pathMembers = RegPath.Split('/');
            //The root path is HKEY_LOCAL_MACHINE. A good modification
            //here would be to use a parameter that specifies the root path.
            regKey = Registry.LocalMachine;
            //Traverse through the registry till we get the proper key
            for (int currentMember=0; currentMember<pathMembers.Length;
                currentMember++)
            {
                //Use CreateSubKey to make sure the key exists
                regKey = regKey.CreateSubKey(pathMembers[currentMember]);
            }   
            return regKey;
        }
    }
}
