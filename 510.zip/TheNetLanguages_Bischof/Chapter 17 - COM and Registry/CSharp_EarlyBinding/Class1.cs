//Getting a program's version number using early binding in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
//Add a COM reference to Microsoft Scripting Runtime
using Scripting;

namespace C_EarlyBinding
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            //Add an early bound reference to the FileSystemObject from
            //the Scripting library (SCCRRUN.DLL)
            FileSystemObject fs = new FileSystemObject();
            //Display a file version number
            string version;
            //You may need to change the path for this file
            version = fs.GetFileVersion(@"C:\WinNT\explorer.exe");
            Console.WriteLine("Windows Explorer - Version {0}", version);
            Console.ReadLine();
        }
    }
}
