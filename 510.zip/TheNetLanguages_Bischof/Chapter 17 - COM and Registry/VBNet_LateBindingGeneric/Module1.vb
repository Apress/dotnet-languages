'A generic COM interface class in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.Reflection

Module Module1

    Sub Main()
        Dim version As String
        Dim fileSystem As CreateObject
        fileSystem = New CreateObject("Scripting.FileSystemObject")
        'You may need to change the path for this file
        version = fileSystem.Execute("GetFileVersion", _
            "C:\WinNT\Explorer.exe").ToString
        Console.WriteLine("Windows Explorer - Version {0}", version)
        Console.ReadLine()
    End Sub

    'Generic class to use late binding for accessing a COM object
    Public Class CreateObject
        'Declare the variables needed for late binding
        Private comType As Type
        Private comObject As Object
        'Constructor takes the ProgID of the COM object
        Public Sub New(ByVal ProgId As String)
            'Reference COM object interface using the ProgID
            comType = Type.GetTypeFromProgID(ProgID)
            'Instantiate the COM object
            comObject = Activator.CreateInstance(comType)
        End Sub
        'Generic call to a late-bound COM method and return a value
        Public Function Execute(ByVal Method As String, _
            ByVal ParamArray Parameters() As Object) As Object
            'Call the method of the COM object
            Return comType.InvokeMember(Method, BindingFlags.InvokeMethod, _
                Nothing, comObject, Parameters)
        End Function
    End Class
End Module
