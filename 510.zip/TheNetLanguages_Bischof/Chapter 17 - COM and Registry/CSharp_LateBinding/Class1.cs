//Getting a program's version number using late binding in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.Reflection;

namespace C_LateBinding
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            //Declare the variables needed for late binding
            Type fsType;
            object fs;
            string[] parameters;

            //Instantiate the COM file system Type object
            fsType = Type.GetTypeFromProgID("Scripting.FileSystemObject");
            //Instantiate the file system object
            fs = Activator.CreateInstance(fsType);
            //Populate the parameter array for passing parameters to object
            parameters = new string[] {@"C:\WinNT\Explorer.Exe"};
            //Call the method of the COM object
            string version;
            //Cast the return value from an object to a string
            version = (string)fsType.InvokeMember("GetFileVersion",
                BindingFlags.InvokeMethod,null,fs,parameters);
            Console.WriteLine("Windows Explorer - Version {0}", version);
            Console.ReadLine();
        }
    }
}
