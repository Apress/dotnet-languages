'A RegEditor class in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports Microsoft.Win32

Module Module1

    Sub Main()
        Dim regEdit As RegEditor
        Dim keyName As String = "Best Sellers"
        Dim keyData As String = "The .Net Languages: " & _
            "A Quick Translation Guide"
        Dim newData As String
        'Tell the user the what key we are going to write
        Console.WriteLine("Writing to Registry")
        Console.WriteLine("Key Name :{0}", keyName)
        Console.WriteLine("Key Value:{0}", keyData)
        'Instantiate the custom registry editor
        regEdit = New RegEditor("SOFTWARE/Apress")
        'Write the string to the registry key
        regEdit.SetValue(keyName, keyData)
        'Read it back to a new variable to check if it worked            
        newData = regEdit.GetValue(keyName)
        Console.WriteLine("Reading from the Registry")
        Console.WriteLine("Key Value:{0}", newData)
        'We're done, so delete it
        Console.WriteLine("Deleting it...")
        regEdit.DeleteValue(keyName)
        newData = regEdit.GetValue(keyName)
        Console.WriteLine("Key Value:{0}", newData)
        Console.WriteLine("Done")
        Console.ReadLine()
    End Sub

    'This class will write keys to a specified path in the registry tree.
    'It is designed to work with the HKey_Local_Machine
    Public Class RegEditor
        Private regKey As RegistryKey
        'Constructor needs the registry path
        Public Sub New(ByVal RegPath As String)
            regKey = GetRegistryKey(RegPath)
        End Sub
        'Write a value to the registry
        Public Sub SetValue(ByVal KeyName As String, ByVal KeyValue As Object)
            regKey.SetValue(KeyName, KeyValue)
        End Sub
        'Get a value from the registry - return strings for simplicity sake
        Public Function GetValue(ByVal KeyName As String) As String
            Return regKey.GetValue(KeyName)
        End Function
        'Delete the value key
        Public Sub DeleteValue(ByVal KeyName As String)
            regKey.DeleteValue(KeyName)
        End Sub
        'Take a registry key path and get the key associated with it
        Private Function GetRegistryKey(ByVal RegPath As String) As RegistryKey
            Dim regKey As RegistryKey
            Dim pathMembers() As String = RegPath.Split("/"c)
            Dim currentMember As Integer
            'The root path is HKEY_LOCAL_MACHINE. A good modification
            'here would be to use a parameter that specifies the root path.
            regKey = Registry.LocalMachine
            'Traverse through the registry till we get the proper key
            For currentMember = 0 To pathMembers.Length - 1
                'Use CreateSubKey to make sure the key exists
                regKey = regKey.CreateSubKey(pathMembers(currentMember))
            Next
            Return regKey
        End Function
    End Class
End Module
