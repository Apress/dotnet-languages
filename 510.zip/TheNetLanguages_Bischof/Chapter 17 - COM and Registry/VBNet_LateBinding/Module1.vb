'Getting a program's version number using early binding in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.Reflection

Module Module1

    Sub Main()
        'Declare the variables needed for late binding
        Dim fsType As Type
        Dim fs As Object
        Dim parameters(0) As String
        'Instantiate the COM file system Type object
        fsType = Type.GetTypeFromProgID("Scripting.FileSystemObject")
        'Instantiate the file system object
        fs = Activator.CreateInstance(fsType)
        'Populate the parameter array for passing parameters to object
        parameters(0) = "C:\WinNT\Explorer.Exe"
        'Call the method of the COM object
        Dim version As String
        'Cast the return value from an object to a string
        version = fsType.InvokeMember("GetFileVersion", _
            BindingFlags.InvokeMethod, Nothing, fs, parameters)
        Console.WriteLine("Windows Explorer - Version {0}", version)
        Console.ReadLine()
    End Sub
End Module
