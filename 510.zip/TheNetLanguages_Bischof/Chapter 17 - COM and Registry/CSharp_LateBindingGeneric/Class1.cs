//A generic COM interface class in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.Reflection;

namespace C_LateBindingGeneric
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            string version;
            CreateObject fileSystem;
            fileSystem = new CreateObject("Scripting.FileSystemObject");
            //You may need to change the path for this file
            version = (string)fileSystem.Execute("GetFileVersion", 
                @"C:\WinNT\Explorer.exe");
            Console.WriteLine("Windows Explorer - Version {0}", version);
            Console.ReadLine();
        }
    }

    //Generic class to use late binding for accessing a COM object
    public class CreateObject
    {
        //Declare the variables needed for late binding
        private Type comType;
        private object comObject;
        //Constructor takes the ProgID of the COM object
        public CreateObject(string ProgID)
        {
            //Reference COM object interface using the ProgID
            comType = Type.GetTypeFromProgID(ProgID);
            //Instantiate the COM object
            comObject = Activator.CreateInstance(comType);
        }
        //Generic call to a late-bound COM method and return a value
        public object Execute(string Method, params object[] Parameters)
        {
            //Call the method of the COM object
            return comType.InvokeMember(Method,BindingFlags.InvokeMethod,
                null,comObject,Parameters);
        }
    }
}
