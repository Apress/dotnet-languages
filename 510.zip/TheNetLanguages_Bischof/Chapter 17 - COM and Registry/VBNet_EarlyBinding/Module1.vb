'Getting a program's version number using early binding in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

'Add a COM reference to Microsoft Scripting Runtime
Imports Scripting

Module Module1

    Sub Main()
        'Add an early bound reference to the FileSystemObject from
        'the Scripting library (SCCRRUN.DLL)
        Dim fs As FileSystemObject = New FileSystemObject()
        'Display a file version number
        Dim version As String
        'You may need to change the path for this file
        version = fs.GetFileVersion("C:\WinNT\explorer.exe")
        Console.WriteLine("Windows Explorer - Version {0}", version)
        Console.ReadLine()
    End Sub
End Module
