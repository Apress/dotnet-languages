//Viewing and updating the Northwind database using C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
using System.Data;  //needed for the DataSet class
using System.Data.SqlClient;

namespace C_ADO
{
    class Class1
    {
        static void Main(string[] args)
        {
            //Declare the Sql objects
            SqlConnection dbCn = new SqlConnection();
            SqlCommand dbCmd = null;
            SqlDataAdapter dbDa = null;
            SqlCommandBuilder dbBldr = null;
            SqlDataReader dbDr = null;
            //Declare the Data objects
            DataSet ds = null;
            DataTable dt = null;
            DataRow dr = null;
            //Declare the user input variables
            int selection = 0; int rowCount = 0;
            string input = "";
            //Open the database connection
            dbCn.ConnectionString = "Server=(local);Uid=sa;Database=NorthWind";
            dbCn.Open();
            //Prepare the SQL statement
            dbCmd = new SqlCommand("Select * From Shippers", dbCn);
            dbCmd.CommandType = CommandType.Text;
            //Read the table into the DataSet using the DataAdapter
            ds = new DataSet();
            dbDa = new SqlDataAdapter();
            dbDa.SelectCommand = dbCmd;
            dbDa.Fill(ds,"Shippers");
            dbBldr = new SqlCommandBuilder(dbDa);
            //Set a reference to the table
            dt = ds.Tables["Shippers"];
            //Don't keep the connection open longer that necessary
            dbCn.Close();  
            Console.WriteLine("ADO.Net");
            do
            {   
                Console.WriteLine("\n1. Print In-Memory Table");
                Console.WriteLine("2. Print Physical Table");
                Console.WriteLine("3. Edit a record");
                Console.WriteLine("4. Add a record");
                Console.WriteLine("5. Delete a record");
                Console.WriteLine("6. Commit Changes to Database");
                Console.Write("Your selection: ");
                selection = int.Parse('0'+Console.ReadLine());
                switch (selection)
                {
                    case 1:     //Print the in memory table
                    Console.WriteLine();
                    for (rowCount=0;rowCount < dt.Rows.Count; rowCount++)
                    {
                        dr = dt.Rows[rowCount];
                        if (dr.RowState != DataRowState.Deleted)
                        {
                            Console.WriteLine("Row #{0}: {1} {2} {3}", 
                                rowCount + 1, dr[0], 
                                dr[1].ToString().PadRight(30), dr[2]);
                        }
                    }
                    break;
                    case 2:     //Print the table in the physical database
                        Console.WriteLine();
                        rowCount=1;
                        dbCn.Open();
                        dbDr = dbCmd.ExecuteReader();
                        while (dbDr.Read())
                        {
                            Console.WriteLine("Row #{0}: {1} {2} {3}",rowCount, 
                               dbDr.GetInt32(0), dbDr.GetString(1).PadRight(30),
                               dbDr.GetString(2));
                        }
                        dbDr.Close();
                        dbCn.Close();
                        break;
                    case 3:     //Edit a row based on the primary key
                        Console.Write("Which Id?");
                        input = Console.ReadLine();
                        //Set the filter to get the selected row
                        dr = dt.Select("ShipperId = "+input)[0];
                        //Get user changes
                        Console.Write("Current : {0} New: ", 
                            dr["CompanyName"]);
                        input = Console.ReadLine();
                        if (input!= "")
                        {
                            dr["CompanyName"] = input;
                        }
                        Console.Write("Current : {0} New: ", dr["Phone"]);
                        input = Console.ReadLine();
                        if (input!= "")
                        {
                            dr["Phone"] = input;
                        }
                        break;
                    case 4:     //Add a new row
                        //Create the row object and populate it
                        dr = dt.NewRow();
                        Console.Write("Company Name: ");
                        input = Console.ReadLine();
                        dr["CompanyName"] = input;
                        Console.Write("Phone: ");
                        input = Console.ReadLine();
                        dr["Phone"] = input;
                        //Add the row object to data table row collection
                        dt.Rows.Add(dr);
                        break;         
                    case 5:     //Delete a row using the row index
                        Console.Write("Row Number: ");
                        input = Console.ReadLine();
                        //Delete the record 
                        dt.Rows[int.Parse(input)-1].Delete();
                        break;
                    case 6:     //Commit the changes to the database
                        //The SQLCommandBuilder will commit all the changes for you
                        dbDa.Update(ds, "Shippers");
                        dt.AcceptChanges();
                        //Clear the current table and refresh it
                        dt.Reset();
                        dbDa.Fill(ds, "Shippers");
                        break;
                }               
            } while (selection!=0);
        }
    }
}
