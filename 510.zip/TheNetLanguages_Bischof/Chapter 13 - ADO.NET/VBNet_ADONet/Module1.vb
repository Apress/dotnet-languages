'Viewing and updating the Northwind database using VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Imports System.Data
Imports System.Data.OleDb

Module Module1

    Sub Main()
        'Declare the OleDb objects
        Dim dbCn As OleDbConnection
        Dim dbCmd As OleDbCommand
        Dim dbDa As OleDbDataAdapter
        Dim dbBldr As OleDbCommandBuilder
        Dim dbDr As OleDbDataReader
        'Declare the Data objects
        Dim ds As DataSet
        Dim dt As DataTable
        Dim dr As DataRow
        'Declare the user input variables
        Dim selection As Integer, rowCount As Integer
        Dim input As String
        'Open the database connection
        dbCn = New OleDbConnection("Provider=Microsoft.JET.OLEDB.4.0;" & _
            "Data Source=C:\Northwind.Mdb")
        dbCn.Open()
        'Prepare the SQL statement
        dbCmd = New OleDbCommand("Shippers", dbCn)
        dbCmd.CommandType = CommandType.TableDirect
        'Read the table into the DataSet using the DataAdapter
        ds = New DataSet()
        dbDa = New OleDbDataAdapter()
        dbDa.SelectCommand = dbCmd
        dbDa.Fill(ds, "Shippers")
        dbBldr = New OleDbCommandBuilder(dbDa)
        'Set a reference to the table
        dt = ds.Tables("Shippers")
        'Don't keep the connection open longer that necessary
        dbCn.Close()
        Console.WriteLine("ADO.Net")
        Do
            Console.WriteLine()
            Console.WriteLine("1. Print In-Memory Table")
            Console.WriteLine("2. Print Physical Table")
            Console.WriteLine("3. Edit a record")
            Console.WriteLine("4. Add a record")
            Console.WriteLine("5. Delete a record")
            Console.WriteLine("6. Commit Changes to Database")
            Console.Write("Your selection: ")
            selection = Integer.Parse("0" & Console.ReadLine())
            Select Case selection
            Case 1 'Print the in memory table
                Console.WriteLine()
                For rowCount = 0 To dt.Rows.Count - 1
                    dr = dt.Rows(rowCount)
                    If dr.RowState() <> DataRowState.Deleted Then
                        Console.WriteLine("Row #{0}: {1} {2} {3}", _
                        rowCount + 1, dr(0), dr(1).ToString.PadRight(30), _
                        dr(2))
                    End If
                Next
            Case 2      'Print the table in the physical database
                Console.WriteLine()
                rowCount = 1
                dbCn.Open()
                dbDr = dbCmd.ExecuteReader()
                While (dbDr.Read())
                    Console.WriteLine("Row #{0}: {1} {2} {3}", rowCount, _
                    dbDr.GetInt32(0), dbDr.GetString(1).PadRight(30), _
                    dbDr.GetString(2))
                    rowCount += 1
                End While
                dbDr.Close()
                dbCn.Close()
            Case 3     'Edit a row based on the primary key
                Console.Write("Which Id?")
                input = Console.ReadLine()
                'Set the filter to get the selected row
                dr = dt.Select("ShipperId = " & input)(0)
                'Get user changes
                Console.Write("Current : {0} New: ", dr("CompanyName"))
                input = Console.ReadLine()
                If (input <> "") Then
                    dr("CompanyName") = input
                End If
                Console.Write("Current : {0} New: ", dr("Phone"))
                input = Console.ReadLine()
                If (input <> "") Then
                    dr("Phone") = input
                End If
            Case 4 'Add a new row
                'Create the row object and populate it
                dr = dt.NewRow()
                Console.Write("Company Name: ")
                input = Console.ReadLine()
                dr("CompanyName") = input
                Console.Write("Phone: ")
                input = Console.ReadLine()
                dr("Phone") = input
                'Add the row object to data table row collection
                dt.Rows.Add(dr)
            Case 5     'Delete a row using the row index
                Console.Write("Row Number: ")
                input = Console.ReadLine()
                'Delete the record 
                dt.Rows(Integer.Parse(input) - 1).Delete()
            Case 6      'Commit the changes to the database
                'The SQLCommandBuilder will commit all the changes for you
                dbDa.Update(ds, "Shippers")
                dt.AcceptChanges()
                'Clear the current table and refresh it
                dt.Reset()
                dbDa.Fill(ds, "Shippers")
            End Select
        Loop While (selection <> 0)
    End Sub
End Module
