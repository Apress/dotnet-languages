//Minimum and maximum numbers in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Math
{
    class Class1
    {
        static void Main(string[] args)
        {
            int qtyToEnter;
            int minimum, maximum;
            int[] values;
            Console.Write("How many numbers to compare? ");
            qtyToEnter = int.Parse(Console.ReadLine());
            //Instantiate an array with the number of elements to enter
            values = new int[qtyToEnter];
            //Enter the numbers into an integer array
            for (int valueIndex=0; valueIndex<qtyToEnter; valueIndex++)
            {
                Console.Write("Enter a number: ");
                values[valueIndex] = int.Parse(Console.ReadLine());
            }
            GetMinMax(out minimum, out maximum, values);
            Console.WriteLine("The minimum is {0}", minimum);
            Console.WriteLine("The maximum is {0}", maximum);
            Console.ReadLine();
        }

        //Calculate the smallest and largest numbers
        static void GetMinMax(out int Minimum, out int Maximum, int[] Values)
        {
            //Initialize the default values
            Minimum = Values[0];
            Maximum = Values[0];
            if (Values.Length > 1)
            {   //Loop through each number to test for the min and max
                for (int valueIndex=1; valueIndex<Values.Length; valueIndex++)
                {
                    Minimum = Math.Min(Minimum, Values[valueIndex]);
                    Maximum = Math.Max(Maximum, Values[valueIndex]);
                }
            }
        }
    }
}