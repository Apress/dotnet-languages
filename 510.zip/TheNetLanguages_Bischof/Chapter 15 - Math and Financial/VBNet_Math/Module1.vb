'Minimum and maximum numbers in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Dim qtyToEnter As Integer
        Dim minimum, maximum As Integer
        Dim values(), valueIndex As Integer
        Console.Write("How many numbers to compare? ")
        qtyToEnter = Integer.Parse(Console.ReadLine())
        'Instantiate an array with the number of elements to enter
        ReDim values(qtyToEnter - 1)
        'Enter the numbers into an integer array
        For valueIndex = 0 To qtyToEnter - 1
            Console.Write("Enter a number: ")
            values(valueIndex) = Integer.Parse(Console.ReadLine())
        Next
        GetMinMax(minimum, maximum, values)
        Console.WriteLine("The minimum is {0}", minimum)
        Console.WriteLine("The maximum is {0}", maximum)
        Console.ReadLine()
    End Sub

    'Calculate the smallest and largest numbers
    Sub GetMinMax(ByRef Minimum As Integer, ByRef Maximum As Integer, _
        ByVal Values() As Integer)
        Dim valueIndex As Integer
        'Initialize the default values
        Minimum = Values(0)
        Maximum = Values(0)
        If (Values.Length > 1) Then
            'Loop through each number to test for the min and max
            For valueIndex = 1 To Values.Length - 1
                Minimum = Math.Min(Minimum, Values(valueIndex))
                Maximum = Math.Max(Maximum, Values(valueIndex))
            Next
        End If
    End Sub

End Module
