'Common financial funcions in VB.Net
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1

    Sub Main()
        Dim rate, per, nper, pmt, pv, fv As Double
        Dim selection As Integer
        Dim result As Double = 0
        Console.WriteLine("Common Financial Functions")
        Console.WriteLine()
        Console.WriteLine("Function Menu")
        Console.WriteLine("1. Present Value (Rate,Years,PMT,FV) ")
        Console.WriteLine("2. Future Value (Rate,Years,PMT,PV)")
        Console.WriteLine("3. Interst Paid (Rate,Per,Years,PV,FV)")
        Console.WriteLine("4. Monthly Payment (Rate,Years,PV,FV)")
        Console.Write("Which function to perform? ")
        selection = Integer.Parse(Console.ReadLine())
        Console.WriteLine("Enter the appropriate value, or zero to skip")
        Console.Write("Interest Rate - whole number: ")
        'The interest rate must be converted to a percentage
        'and then converted to a per month value
        rate = (Double.Parse(Console.ReadLine()) / 100) / 12
        Console.Write("Period: ")
        per = Double.Parse(Console.ReadLine())
        Console.Write("Number of Years: ")
        'Convert number of years to the number of monthly payments
        nper = Double.Parse(Console.ReadLine()) * 12
        Console.Write("Payment: ")
        pmt = Double.Parse(Console.ReadLine())
        Console.Write("Present Value: ")
        'Present value has to be a negative number
        pv = Double.Parse(Console.ReadLine()) * -1
        Console.Write("Future Value: ")
        fv = Double.Parse(Console.ReadLine())
        Select Case selection
            Case 1 'Present Value
                result = Financial.PV(rate, nper, pmt, fv, _
                    DueDate.EndOfPeriod)
            Case 2 'Future Value
                result = Financial.FV(rate, nper, pmt, pv, _
                    DueDate.EndOfPeriod)
            Case 3 'Interest Paid
                result = Financial.IPmt(rate, per, nper, pv, fv, _
                    DueDate.EndOfPeriod)
            Case 4 'Monthly Payment
                result = Financial.Pmt(rate, nper, pv, fv, _
                    DueDate.EndOfPeriod)
        End Select
        Console.WriteLine("The result is {0}", _
            String.Format(result.ToString("n")))
        Console.ReadLine()
    End Sub
End Module
