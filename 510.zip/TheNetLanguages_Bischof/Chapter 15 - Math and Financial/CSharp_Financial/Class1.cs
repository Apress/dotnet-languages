//Common financial funcions in C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;
//The next line requires adding a reference to the 
//Microsoft Visual Basic.Net Runtime 
using Microsoft.VisualBasic;

namespace C_Financial
{
    class Class1
    {
        static void Main(string[] args)
        {
            double rate, per, nper, pmt, pv, fv; 
            int selection;
            double result=0;
            Console.WriteLine("Common Financial Functions\n");
            Console.WriteLine("Function Menu");
            Console.WriteLine("1. Present Value (Rate,Years,PMT,FV) ");
            Console.WriteLine("2. Future Value (Rate,Years,PMT,PV)");
            Console.WriteLine("3. Interst Paid (Rate,Per,Years,PV,FV)");
            Console.WriteLine("4. Monthly Payment (Rate,Years,PV,FV)");
            Console.Write("Which function to perform? ");
            selection = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the appropriate value, or zero to skip");
            Console.Write("Interest Rate - whole number: ");
            //The interest rate must be converted to a percentage
            //and then converted to a per month value
            rate = (double.Parse(Console.ReadLine())/100)/12;
            Console.Write("Period: ");
            per = double.Parse(Console.ReadLine());
            Console.Write("Number of Years: ");
            //Convert number of years to the number of monthly payments
            nper= double.Parse(Console.ReadLine())*12;
            Console.Write("Payment: ");
            pmt = double.Parse(Console.ReadLine());
            Console.Write("Present Value: ");
            //Present value has to be a negative number
            pv = double.Parse(Console.ReadLine())*-1;
            Console.Write("Future Value: ");
            fv = double.Parse(Console.ReadLine());
            switch(selection)
            {
                case 1: //Present Value
                    result = Financial.PV(rate, nper, pmt, fv, 
                        DueDate.EndOfPeriod);
                    break;
                case 2: //Future Value
                    result = Financial.FV(rate, nper, pmt, pv, 
                        DueDate.EndOfPeriod);
                    break;
                case 3: //Interest Paid
                    result = Financial.IPmt(rate, per, nper, pv, fv, 
                        DueDate.EndOfPeriod);
                    break;
                case 4: //Monthly Payment
                    result = Financial.Pmt(rate, nper, pv, fv, 
                        DueDate.EndOfPeriod);
                    break;
            }
            Console.WriteLine("The result is {0}", String.Format
                (result.ToString("n")));
            Console.ReadLine();
            }
    }
}
