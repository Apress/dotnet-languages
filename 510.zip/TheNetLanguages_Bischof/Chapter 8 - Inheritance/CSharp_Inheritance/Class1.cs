//Calculate the price of items for sale using C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Inheritance
{
    class Class1
    {
        static void Main(string[] args)
        {
            Item Magazine = new Item("Magazine");
            Book Bestseller = new Book();
            PrintInfo(Magazine, 10);
            PrintInfo(Bestseller, 5, 15);
            Console.ReadLine(); 
        }
        static void PrintInfo(Item Product, double Price)
        {
            Console.WriteLine("Price of 1 {0} is {1}", Product.Description,                      Product.TotalPrice(Price));
        }
        static void PrintInfo(Item Product, int Qty, double Price)
        {
            Console.WriteLine("Price of {0} {1}S is {2}", Qty, 
                Product.Description, Product.TotalPrice(Qty, Price));
        }
    }

    public class Item
    {
        public string Description;
        //Constructor code - Force the item name to uppercase
        public Item():
            this("")
        {}
        public Item(string Description)
        {
            this.Description = Description.ToUpper();
        }
        //Calculate the total price for all items - the quantity is optional
        public virtual double TotalPrice(double Price)
        {
            return this.TotalPrice(1, Price);
        }
        public virtual double TotalPrice(int Qty, double Price) 
        {
            return Qty * Price;
        }
    }
    
    //This class calculate the price of books
    public class Book: Item
    {
        //Constructor code
        public Book():
            this("Book")
        {} //If no description is supplied, use the default of "Book"
        public Book(string Description):
            base(Description)
        {}
        //Books are sold at a 25% discount
        public override double TotalPrice(int Qty ,double Price)
        {
            double Total;
            Total = base.TotalPrice(Qty, Price);
            Total *= 0.75;
            return Total;
        }
    }
}
