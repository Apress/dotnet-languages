'Calculate the price of items for sale using VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1
    Sub Main()
        Dim Magazine As New Item("Magazine")
        Dim Bestseller As New Book()
        PrintInfo(Magazine, 10)
        PrintInfo(Bestseller, 5, 15)
        Console.ReadLine()
    End Sub
    Public Sub PrintInfo(ByVal Product As Item, ByVal Price As Double)
        Console.WriteLine("Price of 1 {0} is {1}", Product.Description, _
            Product.TotalPrice(Price))
    End Sub
    Public Sub PrintInfo(ByVal Product As Item, ByVal Qty As Integer, _
        ByVal Price As Double)
        Console.WriteLine("Price of {0} {1}S is {2}", Qty, _
            Product.Description, Product.TotalPrice(Qty, Price))
    End Sub

    Public Class Item
        Public Description As String
        'Constructor code - Force the item name to uppercase
        Public Sub New()
            Me.New("")
        End Sub
        Public Sub New(ByVal Description As String)
            Me.Description = Description.ToUpper()
        End Sub
        'Calculate the total price for all items - the quantity is optional
        Public Overridable Function TotalPrice(ByVal Price As Double) As Double
            Return Me.TotalPrice(1, Price)
        End Function
        Public Overridable Function TotalPrice(ByVal Qty As Integer, _
            ByVal Price As Double) As Double
            Return Qty * Price
        End Function
    End Class

    'This class calculate the price of books
    Public Class Book
        Inherits Item
        'Constructor code
        Public Sub New()
            'If no description is supplied, use the default of "Book"
            Me.New("Book")
        End Sub
        Public Sub New(ByVal Description As String)
            MyBase.New(Description)
        End Sub
        'Books are sold at a 25% discount
        Public Overloads Overrides Function TotalPrice(ByVal Qty As Integer, _
            ByVal Price As Double) As Double
            Dim Total As Double
            Total = MyBase.TotalPrice(Qty, Price)
            Total *= 0.75
            Return Total
        End Function
    End Class
End Module
