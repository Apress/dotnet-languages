//Manage a checking account using C#
//Copyright (c)2001 by Bischof Systems, Inc.

using System;

namespace C_Interfaces
{
	class Class1
	{
        [STAThread]
		static void Main(string[] args)
		{
			RunCheckingAccount();
			Console.ReadLine();
		}
        //Run the checking account batch
		static void RunCheckingAccount()
		{
			CCheckingAccount CheckingAccount = new CCheckingAccount();
			CheckingAccount.Deposit(500);
			CheckingAccount.WriteCheck(400);
			CheckingAccount.WriteCheck(75);				
			CheckingAccount.WriteCheck(50);				
		}
		public interface IDebit
		{
			void WriteCheck(double Amount);
			void StatusMessage(string Message);
		}
		public interface ICredit
		{		
			void Deposit(double Amount);
			void StatusMessage(string Message);
		}

		public class CCheckingAccount: IDebit, ICredit
		{
			static double MinimumBalance = 100;
			private double CurrentBalance;
			//Standard constructor
			public CCheckingAccount()
			{}
			//Deposit money into the checking account
			public void Deposit(double Amount)
			{
				CurrentBalance += Amount;
				StatusMessage(String.Format("Deposited ${0}; New Balance is " +
                    "${1}", Amount, CurrentBalance));
            }
			//Withdraw money from the checking account
			public void WriteCheck(double Amount)
			{
				//Check to make sure it isn't below zero
				if ((CurrentBalance - Amount) > 0)
				{
					CurrentBalance -= Amount;
					//Log that the transaction took place
					StatusMessage(String.Format("Withdrew ${0}; New Balance " +
                        "is ${1}", Amount, CurrentBalance));        
                    if (CurrentBalance < MinimumBalance) 
					{
					    //Log that they are below the minimum balance
						StatusMessage(String.Format("You are below the " +
                            "minimum balance of ${0}", MinimumBalance));
					}
				}
				else
				{
					//Log that there wasn't enough funds
					StatusMessage(String.Format("Insufficient funds - ${0} " +
                        "was not withdrawn", Amount));
                 }
			}
			public void StatusMessage(string Message)
			{
				Console.WriteLine(Message);
			}
		}
	}
}