'Manage a checking account using VB .NET
'Copyright (c)2001 by Bischof Systems, Inc.

Module Module1
    Sub Main()
        'Run the checking account batch
        Dim CheckingAccount As New CCheckingAccount()
        CheckingAccount.Deposit(500)
        CheckingAccount.Withdraw(400)
        CheckingAccount.Withdraw(75)
        CheckingAccount.Withdraw(50)
        Console.ReadLine()
    End Sub
    Public Interface ICredit
        Sub Deposit(ByVal Amount As Double)
        Sub StatusMessage(ByVal Message As String)
    End Interface
    Public Interface IDebit
        Sub WriteCheck(ByVal Amount As Double)
        Sub StatusMessage(ByVal Message As String)
    End Interface

    Public Class CCheckingAccount
        Implements IDebit
        Implements ICredit
        Shared MinimumBalance As Double = 100
        Shared LogFile As IO.StreamWriter
        Private CurrentBalance As Double
        'Standard constructor
        Public Sub New()
        End Sub
        'Deposit money into the checking account
        Public Sub Deposit(ByVal Amount As Double) Implements ICredit.Deposit
            CurrentBalance += Amount
            StatusMessage(String.Format("Deposited ${0}; New Balance is " & _
                "${1}", Amount, CurrentBalance))
        End Sub
        'Withdraw money from the checking account
        Public Sub Withdraw(ByVal Amount As Double) Implements IDebit.WriteCheck
            'Check to make sure it isn't below zero
            If (CurrentBalance - Amount) >= 0 Then
                CurrentBalance -= Amount
                'Log that the transaction took place
                StatusMessage(String.Format("Withdrew ${0}; " & _
                    "New Balance is ${1}", Amount, CurrentBalance))
                'Check if the minimum balance was reached
                If CurrentBalance < MinimumBalance Then
                    'Log that it went below the minimum balance
                    StatusMessage(String.Format("You are below the " & _
                        "minimum balance of ${0}", MinimumBalance))
                End If
            Else
                'Log that there wasn't enough funds
                StatusMessage(String.Format("Insufficient funds - ${0} " & _
                    "was not withdrawn", Amount))
            End If
        End Sub
        'This demonstrates using one method to implement two different iterfaces
        Public Sub StatusMessage(ByVal Message As String) _
            Implements ICredit.StatusMessage, IDebit.StatusMessage
            Console.WriteLine(Message)
        End Sub
    End Class
End Module
